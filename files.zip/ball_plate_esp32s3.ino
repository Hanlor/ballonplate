/*
  BALL ON PLATE - firmware ESP32-S3 (2 servo MG995)
  --------------------------------------------------------------------------
  Laptop (Python/OpenCV) gui toa do bi qua Serial, ESP32 chay bo dieu khien
  PD + I tren moi truc roi xuat PWM cho 2 servo.  KHONG can MATLAB.

  GIAO THUC (moi dong ket thuc bang '\n', 115200 baud)
    Laptop -> ESP32
      D,seq,t_ms,x,y        phep do hop le: x,y (cm) tren tam, t_ms = thoi diem chup anh (ms)
      I,seq                 khong thay bi / khong thay tam  (INVALID)
      ARM | DISARM          bat / tat dieu khien vong kin (DISARM = tam ve phang)
      SP x y [vx vy]        diem dat (cm) va van toc dat (cm/s, dung cho bam quy dao)
      TILT x y              (chi khi DISARM) nghieng tam bang tay, don vi do, de hieu chuan
      KP KI KD LAT GEAR LIM ILIM ALPHA BETA <so>     chinh tham so
      C1 <us> | C2 <us>     xung trung tinh servo 1/2 (us)
      MIX a b c d           ma tran tron truc: servo1 = a*ux + b*uy ; servo2 = c*ux + d*uy
      SAVE | RESET | ?      luu NVS / ve mac dinh / in tham so
    ESP32 -> Laptop
      S,state,t_ms,x,y,vx,vy,ux,uy,ix,iy     (20 Hz)  state: 0=DISARM 1=DIEU KHIEN 2=ARM nhung mat bi
      OK / ERR ...                           phan hoi lenh

  QUY UOC
    ux, uy = goc nghieng tam (do) de GIA TOC bi theo +X / +Y.  Chieu dung/sai do MIX quyet dinh.
    GEAR   = so do quay cua servo cho 1 do nghieng tam (phu thuoc tay don, do bang dien thoai).

  AN TOAN
    - Khoi dong o DISARM, tam ve phang (xung trung tinh C1/C2).
    - Mat du lieu > 150 ms hoac nhan goi I  ->  tam ve phang (+ gia tri I da hoc), cho bi xuat hien lai.
    - Gioi han nghieng LIM (do) va gioi han xung cung +-MAX_DEV_US quanh trung tinh.

  Board: ESP32S3 Dev Module.  Neu dung cong USB native: bat "USB CDC On Boot: Enabled".
  Chay duoc tren Arduino-ESP32 core 2.0.x va 3.x.
*/
#include <Arduino.h>
#include <Preferences.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// ============================== CAU HINH PHAN CUNG ==============================
#define PIN_SERVO1 4          // GPIO an toan tren moi bien the S3 (tranh 0,3,19,20,26-37,45,46)
#define PIN_SERVO2 5
#define SERVO_FREQ 50         // Hz
#define SERVO_RES  14         // bit (S3 toi da 14)
#define US_PER_DEG 10.0f      // 10 us / do servo (xap xi; sai so duoc GEAR hieu chuan bu)
#define MAX_DEV_US 350.0f     // gioi han CUNG quanh trung tinh (~35 do servo). Giam neu co khi bi ket.
#define SLEW_US_PER_TICK 60.0f // toc do doi xung toi da moi 20 ms (~300 do servo/s, MG995 khong nhanh hon)
#define SERIAL_BAUD 115200
#define TIMEOUT_MS 150        // het han du lieu -> mat bi
#define STATUS_PERIOD_MS 50   // 20 Hz

#ifndef ESP_ARDUINO_VERSION_MAJOR
#define ESP_ARDUINO_VERSION_MAJOR 2
#endif

#if ESP_ARDUINO_VERSION_MAJOR >= 3
  #define PWM_ATTACH(pin, ch)       ledcAttach(pin, SERVO_FREQ, SERVO_RES)
  #define PWM_WRITE(pin, ch, duty)  ledcWrite(pin, duty)
#else
  #define PWM_ATTACH(pin, ch)       do { ledcSetup(ch, SERVO_FREQ, SERVO_RES); ledcAttachPin(pin, ch); } while (0)
  #define PWM_WRITE(pin, ch, duty)  ledcWrite(ch, duty)
#endif

// ============================== THAM SO ==============================
struct Params {
  uint32_t magic;
  float kp, ki, kd;      // do tam / cm ; do tam / (cm*s) ; do tam / (cm/s)
  float lat;             // s, bu tre camera: dung x + v*lat
  float alpha, beta;     // bo loc alpha-beta
  float gear;            // do servo / do tam
  float lim;             // do, nghieng toi da moi truc
  float ilim;            // do, gioi han thanh phan I
  float c1, c2;          // us trung tinh
  float m[4];            // ma tran tron
};
static const uint32_t PARAM_MAGIC = 0xB0B00002;

static Params P;
static void setDefaults() {
  P.magic = PARAM_MAGIC;
  P.kp = 0.40f; P.ki = 0.04f; P.kd = 0.30f;
  P.lat = 0.06f;
  P.alpha = 0.60f; P.beta = 0.25f;
  P.gear = 2.0f;
  P.lim = 6.0f;
  P.ilim = 2.0f;
  P.c1 = 1500.0f; P.c2 = 1500.0f;
  P.m[0] = 1; P.m[1] = 0; P.m[2] = 0; P.m[3] = 1;
}

struct FloatParam { const char* name; float* ptr; float lo, hi; };
static FloatParam FP[] = {
  {"KP",    &P.kp,    0.0f, 5.0f},
  {"KI",    &P.ki,    0.0f, 1.0f},
  {"KD",    &P.kd,    0.0f, 3.0f},
  {"LAT",   &P.lat,   0.0f, 0.3f},
  {"GEAR",  &P.gear,  0.3f, 8.0f},
  {"LIM",   &P.lim,   0.0f, 12.0f},
  {"ILIM",  &P.ilim,  0.0f, 5.0f},
  {"ALPHA", &P.alpha, 0.05f, 1.0f},
  {"BETA",  &P.beta,  0.0f, 1.0f},
  {"C1",    &P.c1,    1000.0f, 2000.0f},
  {"C2",    &P.c2,    1000.0f, 2000.0f},
};
static const int NFP = sizeof(FP) / sizeof(FP[0]);

static Preferences prefs;
static void saveParams() { prefs.begin("bop", false); prefs.putBytes("p", &P, sizeof(P)); prefs.end(); }
static void loadParams() {
  setDefaults();
  prefs.begin("bop", false);
  if (prefs.getBytesLength("p") == sizeof(Params)) {
    Params t;
    prefs.getBytes("p", &t, sizeof(Params));
    if (t.magic == PARAM_MAGIC) P = t;
  }
  prefs.end();
}

// ============================== TRANG THAI ==============================
struct AB { float x, v; };
static AB fx, fy;                       // bo loc alpha-beta moi truc
static float spx = 8.25f, spy = 5.0f;   // diem dat (cm) - tam 16.5 x 10
static float svx = 0, svy = 0;          // van toc dat (cm/s)
static float ix = 0, iy = 0;            // thanh phan tich phan (do tam)
static float mx = 0, my = 0;            // nghieng thu cong khi DISARM (do)
static float gx = 0, gy = 0;            // lenh nghieng hien hanh (do)
static float lastX = 0, lastY = 0;      // do tho gan nhat (de telemetry)

static bool armed = false;
static bool ballOK = false;
static int  validStreak = 0;
static bool haveLastT = false;
static uint32_t lastT = 0;              // t_ms cua goi D truoc (do laptop gui)
static uint32_t lastValidMs = 0;
static float curUs1, curUs2;            // xung dang xuat (sau slew)

static inline float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
static inline bool ctrlActive() { return armed && ballOK && validStreak >= 3; }

// ============================== PWM ==============================
static void writeUs(int pin, int ch, float us) {
  uint32_t duty = (uint32_t)(us * (float)(1u << SERVO_RES) / 20000.0f + 0.5f);
  PWM_WRITE(pin, ch, duty);
}

static void updateServos() {
  // chon lenh nghieng
  if (!armed)               { gx = clampf(mx, -P.lim, P.lim); gy = clampf(my, -P.lim, P.lim); }
  else if (!ctrlActive())   { gx = clampf(ix, -P.lim, P.lim); gy = clampf(iy, -P.lim, P.lim); }
  // tron truc -> goc servo -> xung
  float d1 = P.gear * (P.m[0] * gx + P.m[1] * gy) * US_PER_DEG;
  float d2 = P.gear * (P.m[2] * gx + P.m[3] * gy) * US_PER_DEG;
  float t1 = P.c1 + clampf(d1, -MAX_DEV_US, MAX_DEV_US);
  float t2 = P.c2 + clampf(d2, -MAX_DEV_US, MAX_DEV_US);
  // gioi han toc do
  curUs1 += clampf(t1 - curUs1, -SLEW_US_PER_TICK, SLEW_US_PER_TICK);
  curUs2 += clampf(t2 - curUs2, -SLEW_US_PER_TICK, SLEW_US_PER_TICK);
  // ghi CA HAI kenh cung mot lan
  writeUs(PIN_SERVO1, 0, curUs1);
  writeUs(PIN_SERVO2, 1, curUs2);
}

// ============================== DIEU KHIEN ==============================
static void abInit(AB& f, float z) { f.x = z; f.v = 0; }
static void abUpdate(AB& f, float z, float dt) {
  float xp = f.x + f.v * dt;
  float r = z - xp;
  f.x = xp + P.alpha * r;
  f.v = f.v + (P.beta / dt) * r;
}

static void resetIntegrators() { ix = 0; iy = 0; }

static void markLost() {
  ballOK = false;
  validStreak = 0;
  haveLastT = false;
}

static void controlStep(float dt) {
  // du doan bu tre camera
  float xs = fx.x + fx.v * P.lat;
  float ys = fy.x + fy.v * P.lat;
  float ex = spx - xs, ey = spy - ys;

  // PD (dao ham theo van toc do - van toc dat)
  float ux = P.kp * ex + P.kd * (svx - fx.v);
  float uy = P.kp * ey + P.kd * (svy - fy.v);

  // I co chong bao hoa: chi tich phan khi sai so nho va lenh chua cham tran
  if (fabsf(ex) < 4.0f && fabsf(ux + ix) < P.lim) ix = clampf(ix + P.ki * ex * dt, -P.ilim, P.ilim);
  if (fabsf(ey) < 4.0f && fabsf(uy + iy) < P.lim) iy = clampf(iy + P.ki * ey * dt, -P.ilim, P.ilim);

  gx = clampf(ux + ix, -P.lim, P.lim);
  gy = clampf(uy + iy, -P.lim, P.lim);
}

// ============================== GOI DU LIEU ==============================
static void handleD(char** tok, int n) {
  if (n < 5) return;
  uint32_t tms = (uint32_t)strtoul(tok[2], NULL, 10);
  float x = atof(tok[3]), y = atof(tok[4]);
  if (!isfinite(x) || !isfinite(y) || fabsf(x) > 60.0f || fabsf(y) > 60.0f) return;

  lastValidMs = millis();
  lastX = x; lastY = y;
  float dt = haveLastT ? (float)((uint32_t)(tms - lastT)) / 1000.0f : 0.0f;

  if (!haveLastT || !ballOK || dt > 0.25f) {     // bat dau lai: khoi tao bo loc
    abInit(fx, x); abInit(fy, y);
    haveLastT = true; lastT = tms; ballOK = true; validStreak = 1;
    return;
  }
  if (dt < 0.004f) return;                        // goi trung / qua sat nhau
  lastT = tms;
  abUpdate(fx, x, dt);
  abUpdate(fy, y, dt);
  if (validStreak < 1000) validStreak++;
  if (ctrlActive()) controlStep(dt);
}

// ============================== LENH ==============================
static void reply(const char* s) { Serial.println(s); }

static void printParams() {
  char b[256];
  snprintf(b, sizeof(b), "P,KP=%.3f KI=%.3f KD=%.3f LAT=%.3f GEAR=%.2f LIM=%.1f ILIM=%.1f ALPHA=%.2f BETA=%.2f",
           P.kp, P.ki, P.kd, P.lat, P.gear, P.lim, P.ilim, P.alpha, P.beta);
  Serial.println(b);
  snprintf(b, sizeof(b), "P,C1=%.0f C2=%.0f MIX=%.2f %.2f %.2f %.2f SP=%.2f,%.2f armed=%d",
           P.c1, P.c2, P.m[0], P.m[1], P.m[2], P.m[3], spx, spy, armed ? 1 : 0);
  Serial.println(b);
}

static int splitLine(char* s, char** tok, int maxTok) {
  int n = 0;
  char* p = strtok(s, " ,\t");
  while (p && n < maxTok) { tok[n++] = p; p = strtok(NULL, " ,\t"); }
  return n;
}

static void handleLine(char* line) {
  char* tok[8];
  int n = splitLine(line, tok, 8);
  if (n == 0) return;
  for (char* c = tok[0]; *c; ++c) *c = toupper((unsigned char)*c);
  const char* cmd = tok[0];

  if (!strcmp(cmd, "D"))  { handleD(tok, n); return; }
  if (!strcmp(cmd, "I"))  { markLost(); return; }

  if (!strcmp(cmd, "ARM")) {
    resetIntegrators(); markLost(); armed = true; reply("OK ARM"); return;
  }
  if (!strcmp(cmd, "DISARM")) { armed = false; resetIntegrators(); reply("OK DISARM"); return; }
  if (!strcmp(cmd, "SP")) {
    if (n < 3) { reply("ERR SP x y [vx vy]"); return; }
    float x = atof(tok[1]), y = atof(tok[2]);
    if (x < 0 || x > 16.5f || y < 0 || y > 10.0f) { reply("ERR SP ngoai tam"); return; }
    spx = x; spy = y;
    svx = (n >= 5) ? atof(tok[3]) : 0.0f;
    svy = (n >= 5) ? atof(tok[4]) : 0.0f;
    return;                                        // khong phan hoi (co the gui 30 Hz)
  }
  if (!strcmp(cmd, "TILT")) {
    if (armed) { reply("ERR DISARM truoc khi TILT"); return; }
    if (n < 3) { reply("ERR TILT x y"); return; }
    mx = atof(tok[1]); my = atof(tok[2]);
    reply("OK TILT"); return;
  }
  if (!strcmp(cmd, "MIX")) {
    if (n < 5) { reply("ERR MIX a b c d"); return; }
    for (int i = 0; i < 4; i++) P.m[i] = clampf(atof(tok[1 + i]), -3.0f, 3.0f);
    reply("OK MIX"); return;
  }
  if (!strcmp(cmd, "SAVE"))  { saveParams(); reply("OK SAVED"); return; }
  if (!strcmp(cmd, "RESET")) { setDefaults(); reply("OK DEFAULTS (chua SAVE)"); return; }
  if (!strcmp(cmd, "?") || !strcmp(cmd, "PARAMS")) { printParams(); return; }

  for (int i = 0; i < NFP; i++) {
    if (!strcmp(cmd, FP[i].name)) {
      if (n < 2) { reply("ERR thieu gia tri"); return; }
      float v = atof(tok[1]);
      if (!isfinite(v) || v < FP[i].lo || v > FP[i].hi) { reply("ERR ngoai khoang cho phep"); return; }
      *FP[i].ptr = v;
      reply("OK");
      return;
    }
  }
  reply("ERR lenh la");
}

static void pollSerial() {
  static char buf[96];
  static int len = 0;
  while (Serial.available()) {
    char c = (char)Serial.read();
    if (c == '\n' || c == '\r') {
      if (len > 0) { buf[len] = 0; handleLine(buf); len = 0; }
    } else if (len < (int)sizeof(buf) - 1) {
      buf[len++] = c;
    } else {
      len = 0;                                     // dong qua dai -> bo
    }
  }
}

static void sendStatus() {
  int state = !armed ? 0 : (ctrlActive() ? 1 : 2);
  char b[160];
  int n = snprintf(b, sizeof(b), "S,%d,%lu,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f\n",
                   state, (unsigned long)millis(), fx.x, fy.x, fx.v, fy.v, gx, gy, ix, iy);
  Serial.write((const uint8_t*)b, n);
}

// ============================== SETUP / LOOP ==============================
void setup() {
  Serial.setRxBufferSize(512);
  Serial.begin(SERIAL_BAUD);
  loadParams();

  curUs1 = P.c1; curUs2 = P.c2;
  PWM_ATTACH(PIN_SERVO1, 0);
  PWM_ATTACH(PIN_SERVO2, 1);
  writeUs(PIN_SERVO1, 0, curUs1);                  // ca hai ve trung tinh cung luc
  writeUs(PIN_SERVO2, 1, curUs2);
  delay(300);
  Serial.println("BOOT ball_plate_esp32s3 DISARMED");
  printParams();
}

void loop() {
  pollSerial();

  uint32_t now = millis();
  if (ballOK && (now - lastValidMs) > TIMEOUT_MS) markLost();   // watchdog du lieu

  static uint32_t tServo = 0, tStatus = 0;
  if (now - tServo >= 20)            { tServo = now;  updateServos(); }
  if (now - tStatus >= STATUS_PERIOD_MS) { tStatus = now; sendStatus(); }
}
